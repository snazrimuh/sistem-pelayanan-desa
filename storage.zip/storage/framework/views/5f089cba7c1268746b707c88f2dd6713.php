

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="container d-flex justify-content-center align-items-center">
        <div class="col-md-8">
            <div class="card shadow">
                <div class="card-body p-4">
                    <h5 class="card-title text-center"><?php echo e(__('Form Pelayanan Desa')); ?></h5>
                    <p class="text-center">Isi form untuk pengajuan pelayanan desa</p>
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e($message); ?>

                    </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('pelayanan.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group mb-3">
                            <label for="jenis_pelayanan"><?php echo e(__('Jenis Pelayanan')); ?></label>
                            <select name="jenis_pelayanan" id="jenis_pelayanan" class="form-select mt-2" required>
                                <option value=""><?php echo e(__('Pilih Jenis Pelayanan')); ?></option>
                                <option value="474 - Pembuatan KTP"><?php echo e(__('Pembuatan KTP')); ?></option>
                                <option value="560 - Pembuatan SKCK"><?php echo e(__('Pembuatan SKCK')); ?></option>
                                <option value="440 - Pembuatan KIS/BPJS"><?php echo e(__('Pembuatan KIS/BPJS')); ?></option>
                                <option value="474.3 - Surat Kematian"><?php echo e(__('Surat Kematian')); ?></option>
                                <option value="474.1 - Surat Kelahiran"><?php echo e(__('Surat Kelahiran')); ?></option>
                                <option value="474 - Surat Izin Kerja"><?php echo e(__('Surat Izin Kerja')); ?></option>
                                <option value="420 - Pembuatan KIP/Pendidikan"><?php echo e(__('Pembuatan KIP/Pendidikan')); ?>

                                </option>
                                <option value="580 - Surat Ket. Usaha/Bank"><?php echo e(__('Surat Ket. Usaha/Bank')); ?></option>
                                <option value="475 - Surat Pindah Penduduk"><?php echo e(__('Surat Pindah Penduduk')); ?></option>
                                <option value="474 - Surat Kehilangan"><?php echo e(__('Surat Kehilangan')); ?></option>
                                <option value="503 - Surat Ket. NPWP"><?php echo e(__('Surat Ket. NPWP')); ?></option>
                                <option value="460 - Surat Sosial Kesra"><?php echo e(__('Surat Sosial Kesra')); ?></option>
                                <option value="412 - BPUM/UMKM"><?php echo e(__('BPUM/UMKM')); ?></option>
                            </select>
                        </div>
                        <div class="form-group mb-3">
                            <label for="nama"><?php echo e(__('Nama')); ?></label>
                            <input type="text" name="nama" id="nama" class="form-control mt-2" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="nik"><?php echo e(__('NIK')); ?></label>
                            <input type="text" name="nik" id="nik" class="form-control mt-2" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="tempat_tgl_lahir"><?php echo e(__('Tempat, Tanggal Lahir')); ?></label>
                            <input type="text" name="tempat_tgl_lahir" id="tempat_tgl_lahir" class="form-control mt-2"
                                required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="no_wa"><?php echo e(__('No WA')); ?></label>
                            <input type="text" name="no_wa" id="no_wa" class="form-control mt-2" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="pekerjaan"><?php echo e(__('Pekerjaan')); ?></label>
                            <input type="text" name="pekerjaan" id="pekerjaan" class="form-control mt-2" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="tempat_tinggal"><?php echo e(__('Tempat Tinggal')); ?></label>
                            <input type="text" name="tempat_tinggal" id="tempat_tinggal" class="form-control mt-2"
                                required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="keperluan"><?php echo e(__('Keperluan')); ?></label>
                            <input type="text" name="keperluan" id="keperluan" class="form-control mt-2" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="tujuan"><?php echo e(__('Tujuan')); ?></label>
                            <input type="text" name="tujuan" id="tujuan" class="form-control mt-2" required>
                        </div>
                        <div class="form-group mb-3">
                            <label for="keterangan_lain"><?php echo e(__('Keterangan Lain')); ?></label>
                            <textarea name="keterangan_lain" id="keterangan_lain" class="form-control mt-2"></textarea>
                        </div>
                        <button type="submit" class="btn mt-2 w-100" style="background-color:#3498DB; color:white">
                            <?php echo e(__('Submit')); ?>

                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Local\Laravel PHP\sistem-pelayanan-desa\resources\views/pelayanan/create.blade.php ENDPATH**/ ?>