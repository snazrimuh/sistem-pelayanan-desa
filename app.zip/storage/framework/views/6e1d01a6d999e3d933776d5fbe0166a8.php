

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="container" style="max-width: 800px;">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <div class="card shadow-sm">
            <div class="card-body p-3">
                <h2 class="text-center mb-4 mt-3"><?php echo e(__('Detail Pengajuan')); ?></h2>
                <div class="d-flex justify-content-between mb-3">
                    <a href="<?php echo e(route('admin.pelayanan.index')); ?>" class="btn btn-primary btn-sm">
                        <?php echo e(__('Kembali')); ?>

                    </a>
                </div>

                <table class="table table-sm table-hover mb-0">
                    <tr>
                        <th><?php echo e(__('Kode Pelayanan')); ?></th>
                        <td><?php echo e($pelayanan->kode_pelayanan); ?></td>
                    </tr>
                    <tr>
                        <th><?php echo e(__('Jenis Pelayanan')); ?></th>
                        <td><?php echo e($pelayanan->jenis_pelayanan); ?></td>
                    </tr>
                    <tr>
                        <th><?php echo e(__('Nama')); ?></th>
                        <td><?php echo e($pelayanan->nama); ?></td>
                    </tr>
                    <tr>
                        <th><?php echo e(__('NIK')); ?></th>
                        <td><?php echo e($pelayanan->nik); ?></td>
                    </tr>
                    <tr>
                        <th><?php echo e(__('Jenis Kelamin')); ?></th>
                        <td><?php echo e($pelayanan->jenis_kelamin); ?></td>
                    </tr>
                    <tr>
                        <th><?php echo e(__('Tempat & Tanggal Lahir')); ?></th>
                        <td><?php echo e($pelayanan->tempat_tgl_lahir); ?></td>
                    </tr>
                    <tr>
                        <th><?php echo e(__('No WA')); ?></th>
                        <td><?php echo e($pelayanan->no_wa); ?></td>
                    </tr>
                    <tr>
                        <th><?php echo e(__('Pekerjaan')); ?></th>
                        <td><?php echo e($pelayanan->pekerjaan); ?></td>
                    </tr>
                    <tr>
                        <th><?php echo e(__('Tempat Tinggal')); ?></th>
                        <td><?php echo e($pelayanan->tempat_tinggal); ?></td>
                    </tr>
                    <tr>
                        <th><?php echo e(__('Keperluan')); ?></th>
                        <td><?php echo e($pelayanan->keperluan); ?></td>
                    </tr>
                    <tr>
                        <th><?php echo e(__('Tujuan')); ?></th>
                        <td><?php echo e($pelayanan->tujuan); ?></td>
                    </tr>
                    <tr>
                        <th><?php echo e(__('Keterangan Lain')); ?></th>
                        <td><?php echo e($pelayanan->keterangan_lain); ?></td>
                    </tr>
                    <tr>
                        <th><?php echo e(__('Tanggal Pengajuan')); ?></th>
                        <td><?php echo e($pelayanan->created_at->format('d-m-Y')); ?></td>
                    </tr>
                </table>
                <div class="d-flex justify-content-between mt-3">
                    <a href="<?php echo e(route('admin.pelayanan.cetak', $pelayanan->id)); ?>" class="btn btn-outline-primary w-100"
                        title="Cetak">
                        <i class="bi bi-printer"></i> <?php echo e(__('Cetak PDF Surat')); ?>

                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Local\Laravel PHP\sistem-pelayanan-desa\resources\views/admin/pelayanan/show.blade.php ENDPATH**/ ?>