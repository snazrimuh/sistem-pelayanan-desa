

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="container">


        <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <div class="card shadow-sm">
            <div class="card-body p-4">
                <h2 class="text-center mb-4 mt-3"><?php echo e(__('Daftar Pengajuan Pelayanan')); ?></h2>
                <div class="table-responsive">
                    <table class="table table-sm table-hover">
                        <thead>
                            <tr>
                                <th><?php echo e(__('Tanggal Pengajuan')); ?></th>
                                <th><?php echo e(__('Jenis Pelayanan')); ?></th>
                                <th><?php echo e(__('Nama')); ?></th>
                                <th><?php echo e(__('Nomor WA')); ?></th>
                                <th class="text-center"><?php echo e(__('Actions')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pelayanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelayanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($pelayanan->created_at->format('d-m-Y')); ?></td>
                                <td><?php echo e($pelayanan->jenis_pelayanan); ?></td>
                                <td><?php echo e($pelayanan->nama); ?></td>
                                <td><?php echo e($pelayanan->no_wa); ?></td>
                                <td class="text-center">
                                    <form action="<?php echo e(route('admin.pelayanan.destroy', $pelayanan->id)); ?>" method="POST"
                                        style="display:inline;"
                                        onsubmit="return confirm('<?php echo e(__('Apakah Anda yakin ingin menghapus pelayanan ini?')); ?>');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm mx-1" title="Hapus">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                    <a href="<?php echo e(route('admin.pelayanan.show', $pelayanan->id)); ?>"
                                        class="btn btn-info btn-sm mx-1" title="Lihat Detail">
                                        <i class="bi bi-eye"></i> Detail
                                    </a>
                                    <a href="<?php echo e(route('admin.pelayanan.cetak', $pelayanan->id)); ?>"
                                        class="btn btn-outline-primary btn-sm mx-1" title="Cetak">
                                        <i class="bi bi-printer"></i> Cetak
                                    </a>
                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Local\Laravel PHP\sistem-pelayanan-desa\resources\views/admin/pelayanan/index.blade.php ENDPATH**/ ?>